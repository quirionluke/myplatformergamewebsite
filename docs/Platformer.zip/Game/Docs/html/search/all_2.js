var searchData=
[
  ['draw',['Draw',['../classUI.html#adb4cbcd5c39529f361c6543471e939a7',1,'UI']]]
];
