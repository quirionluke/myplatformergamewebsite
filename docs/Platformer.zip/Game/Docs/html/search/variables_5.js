var searchData=
[
  ['screen_5fheight',['SCREEN_HEIGHT',['../textInput_8cpp.html#ab454541ae58bcf6555e8d723b1eb95e7',1,'textInput.cpp']]],
  ['screen_5fwidth',['SCREEN_WIDTH',['../textInput_8cpp.html#a3482785bd2a4c8b307f9e0b6f54e2c36',1,'textInput.cpp']]]
];
