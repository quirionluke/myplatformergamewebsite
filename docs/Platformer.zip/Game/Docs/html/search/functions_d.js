var searchData=
[
  ['tilemap',['TileMap',['../classTileMap.html#aa95209220358e080a792317d27fb0781',1,'TileMap']]],
  ['transformcomponent',['TransformComponent',['../classTransformComponent.html#ace1cf2d7d2a7468e9cb3eb0ce382f446',1,'TransformComponent::TransformComponent()'],['../classTransformComponent.html#af9d6d44ebc2f661ffe8b7181befca705',1,'TransformComponent::TransformComponent(int xpos, int ypos)']]]
];
