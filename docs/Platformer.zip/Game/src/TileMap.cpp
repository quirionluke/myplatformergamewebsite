#include <iostream>
#include <iomanip>
#include <fstream>

#include "TileMap.hpp"
using namespace std;

// Creates a new tile map.
// rows and cols are how many different tiles there are in the sprite sheet
// 
// _TileWidth and _TileHeight are the size of each individual
// tile in the sprite sheet.
// (Typically this works best if they are square for this implementation.)
//
// _mapX, and _mapY are the size of the tilemap. This is the actual
// number of tiles in the game that the player sees, not how many tiles
// are in the actual sprite sheet file loaded.
TileMap::TileMap(std::string tileSheetFileName, int rows, int cols, int _TileWidth, int _TileHeight, int _mapX, int _mapY, SDL_Renderer* ren){
    if(nullptr==ren){
        SDL_Log("No valid renderer found");
    }

    // Setup variables
    m_Rows = rows;
    m_Cols = cols;
    m_TileWidth = _TileWidth;
    m_TileHeight = _TileHeight;
    m_MapX = _mapX;
    m_MapY = _mapY;
    // Load the TileMap Image
    // This is the image that will get
    // sliced into smaller subsections of individual tiles.
    m_TileSpriteSheet = SDL_LoadBMP(tileSheetFileName.c_str());
	
    if(nullptr == m_TileSpriteSheet){
           SDL_Log("Failed to allocate surface");
    }else{
        // Create a texture from our surface
        // Textures run faster and take advantage of
        //  hardware acceleration
        m_Texture = SDL_CreateTextureFromSurface(ren, m_TileSpriteSheet);
    }

    // Setup the TileMap array
    // This sets each tile to '0'
    m_Tiles = new int[m_MapX*m_MapY];
    for(int i=0; i < m_MapX*m_MapY; i++){
        m_Tiles[i] = -1; // Default value is no tile.
    }
}

// Destructor
TileMap::~TileMap(){
    SDL_DestroyTexture(m_Texture);
    // Remove our TileMap
    delete[] m_Tiles;
}

// Helper function to get a tilemap from a file
void TileMap::ReadMapFromFile(std::string fileName) {
    std::ifstream infile(fileName);

    int x = 0;
    int y = 0;
    int t = 0;
    std::string s = "";

    //reads to white space and writes that to s
    while (std::getline(infile, s)) {
    std::string b = "";
    int subStart = 0;
    for (int i = 0; i < s.length(); i++) {
        if (s.at(i) == ' ') {
            b = s.substr(subStart, i);
            t = std::stoi(b);
            printf("%d\n", t);
            SetTile(x, y, t);
            x++;
            subStart = i + 1;
        }
        }
        x = 0;
        ++y;
    }

}


// Helper function to gegenerate a simlpe map
void TileMap::GenerateSimpleMap(){
    for(int y= 0; y < m_MapY; y++){
        for(int x= 0; x < m_MapX; x++){
            /*
            12, upper left corner
            11, upper right corner
            10, left side
            9, blank (light)
            8, right side
            7, blank (dark)
            6, blank
            5, blank
            4, bottom left corner
            3, bottom right corner
            2, grass edge right
            1, grass straight
            0, grass edge left


            #sample map with a whole in the middle

            12 _________ 11
            8 -1-1-1-1-1 10
            8 -1-1-1-1-1 10
            4  1 1 2-1 0 3

            */

           //Assign borders and background sky
           switch(y){
               case 0:
                    if(x==0) {
                        SetTile(x,y,25);
                    }
                    else if (x==m_MapX-1)
                    {
                        SetTile(x,y,11);
                    }
                    else {
                        SetTile(x,y,17);
                    }
                    break;
               default:
                    SetTile(x,y,-1);
                    break;
           }

           switch(x){
               case 0:
                    if(y==0) {
                        SetTile(x,y,25);
                    }
                    else if (y==m_MapY-1)
                    {
                        SetTile(x,y,33);
                    }
                    else {
                        SetTile(x,y,10);
                    }
                    break;
                default:
                    break;
                    
            }

            if(x==m_MapX-1) {
                if (y!=0 && y!=m_MapY-1)
                {
                    SetTile(x,y,-1);
                }
                else if (y==m_MapY-1)
                {
                    SetTile(x,y,32);
                }
                else if (y==0)
                {
                    SetTile(x,y,24);
                }
                
                

            }

            if(y==m_MapY-1) {
                if(x!=0 && x!=m_MapX-1) {
                    SetTile(x,y,1);
                }
                else if (x==0)
                {
                    SetTile(x,y,33);
                }
                
            }

            if(y==4) {
                if(x!=0){
                    SetTile(x,y,1);
                }
            }
       }
    }
}

// Helper function to print out the tile map
// to the console
void TileMap::PrintMap(){
    for(int y= 0; y < m_MapY; y++){
        for(int x= 0; x < m_MapX; x++){
            std::cout << std::setw(3) << GetTileType(x,y);
       }
         std::cout << "\n";
    }
}

//Helper function to return our tile map
int* TileMap::ReturnMap() {
    int* t_Tiles = new int[m_MapX * m_MapY];
    for (int i = 0; i < m_MapX * m_MapY; i++) {
        t_Tiles[i] = m_Tiles[i]; // Default value is no tile.
    }
    return t_Tiles;
}

// Sets a tile a certain type
void TileMap::SetTile(int x, int y, int type){
    m_Tiles[y * m_MapX + x] = type;
}


// Returns what the tile is at a specific position.
int TileMap::GetTileType(int x, int y){
    return m_Tiles[y * m_MapX + x];
}

void TileMap::Update(){
    
}

// render TileMap
void TileMap::Render(SDL_Renderer* ren){
    if(nullptr==ren){
        SDL_Log("No valid renderer found");
    }
    
    SDL_Rect Src, Dest;
    for(int y= 0; y < m_MapY; y++){
        for(int x= 0; x < m_MapX; x++){
            // Select our Tile
            int currentTile = GetTileType(x,y);
            if(currentTile > -1 ){
                // Reverse lookup, given the tile type
                // and then figuring out how to select it
                // from the texture atlas.
                Src.x = (currentTile % m_Cols) * m_TileWidth;
                Src.y = (currentTile / m_Rows) * m_TileHeight;
                Src.w = m_TileWidth; 
                Src.h = m_TileHeight; 
                // Render our Tile at this location
                Dest.x = x*m_TileWidth;
                Dest.y = y*m_TileHeight;
                Dest.w = m_TileWidth;
                Dest.h = m_TileHeight;
                SDL_RenderCopy(ren, m_Texture, &Src, &Dest);
            }
        }
    }
}
