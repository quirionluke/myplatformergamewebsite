#include "EnemyBehavior.hpp"
#include "Engine.hpp"

EnemyBehavior::EnemyBehavior() {
}

EnemyBehavior::~EnemyBehavior() {
}

TransformComponent* EnemyBehavior::GetTransform() {
    return trans;
}

ColliderComponent* EnemyBehavior::GetCollider() {
    return col;
}

void EnemyBehavior::SetTransform(TransformComponent* trans) {
    this->trans = trans;
    //set min and max position to 50 more and 50 less than starting
    maxX = this->trans->GetPositionX() + 50;
    minX = this->trans->GetPositionX() - 50;
}

void EnemyBehavior::SetCollider(ColliderComponent* col) {
    this->col = col;
}

void EnemyBehavior::SetPlayerCollider(ColliderComponent* playercol) {
    this->playercol = playercol;
}

bool EnemyBehavior::CheckMyCollisions(ColliderComponent other) {
    //calls check collisions from its component
    return col->CheckCollisions(other);
}

void EnemyBehavior::HandleCollision() {
    //car crash behavior
    playercol->GetTransform()->SetPosition(128, 525);
    
    
    //printf("hit the player at %d, %d\n", col->GetTransform()->GetPositionX(), col->GetTransform()->GetPositionY());
}

void EnemyBehavior::MoveEnemy() {
    //check to see if enemy is at or past its bounds
    //if it is update its velocity to move back
    if (trans->GetPositionX() >= maxX) {
        trans->SetXVelocity(-1);
    }
    else if (trans->GetPositionX() <= minX) {
        trans->SetXVelocity(1);
    }
}

void EnemyBehavior::Update() {
    //check if enemy velocity needs to be chaged
    MoveEnemy();
    //update my position
    trans->Update();
    //Do we need to update col position also?
    col->SetColliderPos(trans->GetPositionX(), trans->GetPositionY());
    
    //check if the player hits the rocks
        //how do we give this access to the player game object so that we can access its collider component?
        //Also does the collider component update with it's parent's transform or with its personal transform?

    //printf("poscol: %d, %d poscaar: %d, %d\n", col->GetCollider().x, col->GetCollider().y, trans->GetPositionX(), trans->GetPositionY());
    
    //what happens when we hit the player?

    bool colliding = col->CheckCollisions(*playercol);

    if(colliding) {
        HandleCollision();
    }
    

    
}

void EnemyBehavior::Render(SDL_Renderer* renderer) {

}
