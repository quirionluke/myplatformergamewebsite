#include "Engine.hpp"
#include "Sprite.hpp"
#include "TileMap.hpp"
#include "ControllerComponent.hpp"
#include "EnemyBehavior.hpp"
#include "FinishLineBehavior.hpp"
#include "UI.h"
// I recommend a map for filling in the resource manager
#include <map>
#include <string>
#include <memory>
#include <iterator>
#include <SDL2/SDL_mixer.h>


// Try toggling this number!
#define CHARACTERS 1


SDL_Rect Engine::camera = {0,0,1920, 1280};

GameObject* player;
GameObject* mapoftiles;
TransformComponent* tc;

//Global variables
int* mymap;
int tileW = 64;
int tileH = 64;

int tileMapX = 64;
int tileMapY = 11;



// Initialization function
// Returns a true or false value based on successful completion of setup.
// Takes in dimensions of window.
Engine::Engine(){
}


// Proper shutdown and destroy initialized objects
Engine::~Engine(){
}

// Return Input
void Engine::Input(bool *quit){
    // Event handler that handles various events in SDL
    // that are related to input and output
    SDL_Event e;
    // Enable text input
    SDL_StartTextInput();
      //Handle events on queue
      while(SDL_PollEvent( &e ) != 0){
        // User posts an event to quit
        // An example is hitting the "x" in the corner of the window.
        if(e.type == SDL_QUIT){
          *quit = true;
        }
        else {
            for(std::vector<GameObject>::iterator it = allObjects.begin(); it != allObjects.end(); ++it) {
                it->HandleInputs(e);
            }
        }
    }
}

// Update SDL
void Engine::Update()
{
    /*
    for(everytile in tile  map){
        if(tiletype != -1){
            if(check collsion against player){
                player velocity = 0;
                player position -= intersection
            }
        }
    }
    */



    for(std::vector<GameObject>::iterator it = allObjects.begin(); it != allObjects.end(); ++it) {
         it->Update();
    }

    //This is supposed to create a sudo "CollisionComponent" list and check tile collision for every tile that isn't air
    int myX = 0; //keep track of x in array
    int myY = 0; //keep track of y in array
    //loop through my array
    for (int ii = 0; ii < tileMapX * tileMapY; ii++) {
        //if we are at the end of a row set x to 0 and increase our row count (y) by 1
        if (ii - tileMapX == 0) {
            ++myY;
            myX = 0;
        }
        //save tile type to temp int
        int tt = mymap[ii];
        
        //if tile is not air
        if (tt != -1) {
            //check collision with player
            int x = myX * 8; //This is x pos I think comparing it to how tilemap works for rendering
            int y = myY * 8;
            player->CheckCollision(x, y, 8, 8);
        }
        //increase our x count
        ++myX;
    }

    camera.x =tc->GetPositionX() * -1 + 200;

    if(camera.x >= 0) {
        camera.x = 0;
    }
    else if(camera.x <= 1280-(64* tileMapX)) { 
        camera.x = 1280-(64*tileMapX);
    }

    SDL_RenderSetViewport(m_renderer->GetRenderer(), &camera);


}


// Render
// The render function gets called once per loop
void Engine::Render(){
    // Set the color of the empty framebuffer
    m_renderer->SetRenderDrawColor(110, 130,170,0xFF);
    // Clear the screen to the color of the empty framebuffer
    m_renderer->RenderClear();


    for(std::vector<GameObject>::iterator it = allObjects.begin(); it != allObjects.end(); ++it) {
        it->Render(m_renderer->GetRenderer());
    }

    // Flip the buffer to render
    m_renderer->RenderPresent();
}



//Loops forever!
void Engine::MainGameLoop(){
    // Main loop flag
    // If this is quit = 'true' then the program terminates.
    bool quit = false;

    int startTime, currentTime, fpsTime = 0;
    int fpsCounter = 0;

    // While application is running
    while(!quit){
      // Get user input
      Input(&quit);
      // If you have time, implement your frame capping code here
      // Otherwise, this is a cheap hack for this lab.
      currentTime = SDL_GetTicks();

        if(currentTime - fpsTime <= 1000.0f/60.0f) {
            Uint32 elapsedTime = currentTime - fpsTime;
            SDL_Delay(1000.0f/60.0f - elapsedTime);
            currentTime = SDL_GetTicks();
        }

        fpsTime = currentTime;
        if(currentTime > startTime + 1000) {
		    startTime = currentTime;
		    fpsCounter = 0;
	    }

      // Update our scene
      Update();
      // Render using OpenGL
      Render();
      //Update screen of our specified window
      fpsCounter++;
    }
    //Disable text input
    SDL_StopTextInput();
}

void Engine::Start(){
    // Report which subsystems are being initialized
    if(m_renderer!=nullptr){
        std::cout << "Initializing Graphics Subsystem\n";
    }else{
        std::cout << "No Graphics Subsystem initialized\n";
    }
    Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048);

    TTF_Init();

    Mix_Volume(1, MIX_MAX_VOLUME);

    Mix_Music* backgroundmusic = Mix_LoadMUS("./Assets/bgmsound.mp3");
    font = TTF_OpenFont("./Assets/gamefont.ttf", 40);
    
    //Establish the ui
    winlose = new UI(64*(tileMapX-2), 64*(tileMapY-4), m_renderer->GetRenderer(), font);

    mapoftiles = new GameObject();
    TileMap* maptiletilemap = new TileMap("./Assets/Tiles1.bmp", 8,8,tileH,tileW,tileMapX,tileMapY,m_renderer->GetRenderer());
    //maptiletilemap->ReadMapFromFile("/Assets/level1.txt");
    maptiletilemap->GenerateSimpleMap();
    maptiletilemap->PrintMap();

    mymap = maptiletilemap->ReturnMap();
    
    mapoftiles->AddComponent(maptiletilemap);
    allObjects.push_back(*mapoftiles);

    //Setting up the player
    player = new GameObject();
    tc=new TransformComponent();
    tc->SetPosition(128,525);
    tc->SetVelocity(0,0);
    ColliderComponent* coll=new ColliderComponent(tc, 128, 128);
    ControllerComponent* cc = new ControllerComponent(tc, coll);
    cc->SetTileMaplistOfTiles(mymap);
    Sprite* sprite = new Sprite(tc);
    sprite->LoadImage("./Assets/car.bmp",m_renderer->GetRenderer());

    //I picked an random small size since I don't know the size of the sprite  for testing purposes
    //coll->SetColliderPos(128,525);

    player->AddComponent(tc);
    player->AddComponent(cc);
    player->AddComponent(sprite);
    player->AddComponent(coll);
    allObjects.push_back(*player);
    //done setting up player

    //Setting up the rival car
    GameObject* enemy = new GameObject();
    TransformComponent* tce=new TransformComponent();
    ColliderComponent* cce = new ColliderComponent(tce);
    tce->SetPosition(128,130);
    tce->SetVelocity(5,0);
    Sprite* spritee = new Sprite(tce);
    spritee->LoadImage("./Assets/rival.bmp",m_renderer->GetRenderer());

    
    enemy->AddComponent(tce);
    enemy->AddComponent(cce);
    enemy->AddComponent(spritee);
    allObjects.push_back(*enemy);
    //done setting up rival car


    //This enemy below is made to test the EnemyBehavior movement Feel free to remove it if you don't want it
    GameObject* testEnemy = new GameObject();
    TransformComponent* teTCE = new TransformComponent();
    teTCE->SetPosition(1280, 525);
    teTCE->SetVelocity(1, 0);
    ColliderComponent* teCOLL = new ColliderComponent(teTCE, 128, 128);
    //teCOLL->SetColliderPos(400, 525);

    //With the enemy behavior component we would want to add the collision and transform to our behavior then add the behavior to our enemy I think
    EnemyBehavior* teEB = new EnemyBehavior();
    teEB->SetTransform(teTCE);
    teEB->SetCollider(teCOLL);
    teEB->SetPlayerCollider(coll);
    
    Sprite* spriteT = new Sprite(teTCE);
    spriteT->LoadImage("./Assets/enemy.bmp", m_renderer->GetRenderer());

    testEnemy->AddComponent(teEB);
    //testEnemy->AddComponent(teTCE);
    testEnemy->AddComponent(spriteT);
    allObjects.push_back(*testEnemy);


    //set up the finish line
    GameObject* finishline = new GameObject();
    TransformComponent* finishTrans = new TransformComponent();
    finishTrans->SetPosition(64*(tileMapX-2), 500);
    finishTrans->SetVelocity(0,0);
    ColliderComponent* finCol = new ColliderComponent(finishTrans, 128, 128);

    //this is where game winning behavior will go
    FinishLineBehavior* finbeh = new FinishLineBehavior(winlose);
    finbeh->SetTransform(finishTrans);
    finbeh->SetCollider(finCol);
    finbeh->SetPlayerCollider(coll);

    Sprite* spriteFin = new Sprite(finishTrans);
    spriteFin->LoadImage("./Assets/finishline.bmp", m_renderer->GetRenderer());

    finishline->AddComponent(finbeh);
    finishline->AddComponent(spriteFin);
    allObjects.push_back(*finishline);

    //finish setting up the finish line

    //set up rival's finish line
    GameObject* finishline2 = new GameObject();
    TransformComponent* finishTrans2 = new TransformComponent();
    ColliderComponent* fincol2 = new ColliderComponent(finishTrans2, 128, 128);
    FinishLineBehavior* finbeh2 = new FinishLineBehavior(winlose);
    finbeh2->SetTransform(finishTrans2);
    finbeh2->SetCollider(fincol2);
    finbeh2->SetPlayerCollider(cce);
    finishTrans2->SetPosition(64*(tileMapX-2), 130);
    finishTrans2->SetVelocity(0,0);
    Sprite* spriteFin2 = new Sprite(finishTrans2);
    spriteFin2->LoadImage("./Assets/finishline.bmp", m_renderer->GetRenderer());

    finishline2->AddComponent(finishTrans2);
    finishline->AddComponent(spriteFin2);
    allObjects.push_back(*finishline2);
    

    camera.x = 0;
    camera.y = 0;
    camera.w = 64*tileMapX;
    camera.h = 64*tileMapY;

    SDL_RenderSetViewport(m_renderer->GetRenderer(), &camera);

    Mix_PlayMusic(backgroundmusic, -1);
    Mix_VolumeMusic(20);




}

void Engine::Shutdown(){
    // Shut down our Tile Systems
    if(nullptr!=m_renderer){
        delete m_renderer;
    } 


    for(std::vector<GameObject>::iterator it = allObjects.begin(); it != allObjects.end(); ++it) {
        allObjects.pop_back();
    }

    TTF_Quit();    
}

void Engine::InitializeGraphicsSubSystem(){
    // Setup our Renderer
    m_renderer = new GraphicsEngineRenderer(1280,720);
    if(nullptr == m_renderer){
        exit(1); // Terminate program if renderer 
                 // cannot be created.
                 // (Optional) TODO:   Could put an error 
                 //                    messeage, or try to 
                 //                    reinitialize the engine 
                 //                    with a different render
    }
}
