#include "FinishLineBehavior.hpp"
#include "Engine.hpp"

FinishLineBehavior::FinishLineBehavior(UI* gameendfont) {
    this->gameendfont = gameendfont;
}

FinishLineBehavior::~FinishLineBehavior() {
    this->gameendfont = nullptr;
}

TransformComponent* FinishLineBehavior::GetTransform() {
    return trans;
}

ColliderComponent* FinishLineBehavior::GetCollider() {
    return col;
}



void FinishLineBehavior::SetTransform(TransformComponent* trans) {
    this->trans = trans;
    //set min and max position to 50 more and 50 less than starting
    maxX = this->trans->GetPositionX() + 50;
    minX = this->trans->GetPositionX() - 50;
}

void FinishLineBehavior::SetCollider(ColliderComponent* col) {
    this->col = col;
}

void FinishLineBehavior::SetPlayerCollider(ColliderComponent* playercol) {
    this->playercol = playercol;
}

bool FinishLineBehavior::CheckMyCollisions(ColliderComponent other) {
    //calls check collisions from its component
    return col->CheckCollisions(other);
}

//This method is what happens when you win
void FinishLineBehavior::HandleCollision() {
    playercol->GetTransform()->SetPosition(128, 525);
    
    char dest[50];
    sprintf(dest, "You Win");
    gameendfont->SetText(dest);
    printf("%s\n", dest);
    printf("Next Lap!\n");
    gameendfont->Draw();
    //printf("finished the player at %d, %d\n", col->GetTransform()->GetPositionX(), col->GetTransform()->GetPositionY());
}

void FinishLineBehavior::Update() {
    //update my position
    trans->Update();
    //Do we need to update col position also?
    col->SetColliderPos(trans->GetPositionX(), trans->GetPositionY());
    
    //check if the player hits the rocks
        //how do we give this access to the player game object so that we can access its collider component?
        //Also does the collider component update with it's parent's transform or with its personal transform?

    //printf("poscol: %d, %d poscaar: %d, %d\n", col->GetCollider().x, col->GetCollider().y, trans->GetPositionX(), trans->GetPositionY());
    
    //what happens when we hit the player?

    bool colliding = col->CheckCollisions(*playercol);

    if(colliding) {
        HandleCollision();
    }
    

    
}

void FinishLineBehavior::Render(SDL_Renderer* renderer) {

}
