#include "GameObject.hpp"

GameObject::GameObject(){
}    

GameObject::~GameObject(){
    m_components.clear();
}

void GameObject::Update() {
    for(std::vector<Component*>::iterator it = m_components.begin(); it != m_components.end(); ++it) {
        (*it)->Update();
    }
}

void GameObject::CheckCollision(int leftB, int topB, int myWidth, int myHeight) {
    for (std::vector<Component*>::iterator it = m_components.begin(); it != m_components.end(); ++it) {
        ColliderComponent* contr = dynamic_cast<ColliderComponent*>(*it);
        if (contr) {

            //Check for collisions and save the return int to a value to check later
            int checkMe = contr->CheckCollisions(leftB, topB, myWidth, myHeight);
            
            //Check that a collision occured
            if(checkMe != -1){

                // player pos -= player velocity

                //Iterate through my componetns until i find my transform component
                for (std::vector<Component*>::iterator dumb = m_components.begin(); dumb != m_components.end(); ++dumb) {
                    TransformComponent* myTrans = dynamic_cast<TransformComponent*>(*dumb);
                    if (myTrans) {
                        //if top or bottom
                        if (checkMe == 1) {
                            int myVY = myTrans->GetVelocityY();

                            //This line below is what is "supposed" to update on collisions
                            //myTrans->SetPosition(myTrans->GetPositionX(), myTrans->GetPositionY() + (-1 * myVY));
                        }
                        //else left or right
                        else {
                            int myVX = myTrans->GetVelocityX();
                            //myTrans->SetPosition(myTrans->GetPositionX() + (-1 * myVX), myTrans->GetPositionY());

                            //basic test line
                           //myTrans->SetPosition(myTrans->GetPositionX() + 1, myTrans->GetPositionY());
                        }
                    }
                }
            }
        }
    }
}

void GameObject::HandleInputs(SDL_Event e) {
        for(std::vector<Component*>::iterator it = m_components.begin(); it != m_components.end(); ++it) {
            ControllerComponent* contr = dynamic_cast<ControllerComponent*>(*it);
            if(contr) {
                contr->HandleInputs(e);
            }
        }
}

void GameObject::Render(SDL_Renderer* renderer) {
    for(std::vector<Component*>::iterator it = m_components.begin(); it != m_components.end(); ++it) {
        (*it)->Render(renderer);
    }    
}

void GameObject::AddComponent(Component* comp) {
    m_components.push_back(comp);
}

void GameObject::RemoveComponent(){
    m_components.pop_back();
}