#include <string.h>
#include "SDL2/SDL.h"
#include "SDL2/SDL_image.h"
#include "SDL2/SDL_ttf.h"

#include "UI.h"

UI::UI(float x, float y, SDL_Renderer* renderer, TTF_Font* font) : renderer(renderer), font(font){
    surface = TTF_RenderText_Solid(font, " ", {0xFF, 0xFF, 0xFF, 0xFF});
    texture = SDL_CreateTextureFromSurface(renderer, surface);
    
	SDL_QueryTexture(texture, nullptr, nullptr, &width, &height);

    rect.x = static_cast<int>(x);
    rect.y = static_cast<int>(y);
    rect.w = width;
    rect.h = height;
}

UI::~UI()
{
    SDL_FreeSurface(surface);
    SDL_DestroyTexture(texture);
}

void UI::Draw()
{
    SDL_RenderCopy(renderer, texture, nullptr, &rect);
}

void UI::SetText(char * text)
{
    SDL_FreeSurface(surface);
    SDL_DestroyTexture(texture);

    surface = TTF_RenderText_Solid(font, text, {0xFF, 0xFF, 0xFF, 0xFF});
    texture = SDL_CreateTextureFromSurface(renderer, surface);

    SDL_QueryTexture(texture, nullptr, nullptr, &width, &height);
    rect.w = width;
    rect.h = height;
}