#include "ControllerComponent.hpp"
#include "ColliderComponent.hpp"

ControllerComponent::ControllerComponent(TransformComponent* trans, ColliderComponent* col): Component(){
  this->trans = trans;
  this->col = col;

  buttons[0] = false;
  buttons[1] = false;
  groundy = trans->GetPositionY();
}

ControllerComponent::~ControllerComponent(){
  trans = nullptr;
  col = nullptr;
}


bool ControllerComponent::CheckMoveUp() {
  return canMoveUp;
}

bool ControllerComponent::CheckMoveDown() {
  return canMoveDown;
}

bool ControllerComponent::CheckMoveLeft() {
  return canMoveLeft;
}

bool ControllerComponent::CheckMoveRight() {
  return canMoveRight;
}

//Updates the "canmoves" based on this's relationship to other
//this is a and other is b
void ControllerComponent::UpdateCanMove() {
  
}

void ControllerComponent::HandleInputs(SDL_Event e) {
  // Event handler that handles various events in SDL        
      if(e.type==SDL_KEYDOWN){//this is where we check for inputs
          if(e.key.keysym.sym == SDLK_a) {
              buttons[0]=true;
          }
          else if(e.key.keysym.sym == SDLK_d) {
              buttons[1]=true;
          }
          else if(e.key.keysym.sym == SDLK_SPACE) {
              buttons[2] = true;
            
          }
      }
      else if(e.type==SDL_KEYUP){
          if(e.key.keysym.sym == SDLK_a) {
              buttons[0]=false;
          }
          else if(e.key.keysym.sym == SDLK_d) {
              buttons[1]=false;
          }
          else if(e.key.keysym.sym == SDLK_SPACE) {
              buttons[2]=false;
          }
      }
      

      //moving left and right
      if(buttons[0]) {
        //printf("buttons 0\n");
        if(trans->facingright) {
          trans->facingright = false;
        }

        if(!trans->GetPositionX() < 64) {

        
          trans->SetXVelocity(-10);
        }
        
      }
      else if(buttons[1]) {
        //printf("buttons 1\n");
        if(!trans->facingright) {
          trans->facingright = true;
        }
          trans->SetXVelocity(10);
        
      }
      else {
        trans->SetXVelocity(0);
      }

      if(trans->GetPositionX() < 64) {
          trans->SetXVelocity(0);
          trans->SetXPosition(64);
      }



      if(buttons[2]) {
        //handle the jumping
        if(!trans->IsJumping()) {
          trans->SetJumping(true);
          if(trans->GetPositionY() >= groundy-150) {
            trans->SetYVelocity(-5);
          }
        }
      }
      else{
        if(trans->IsJumping()){
          //printf("buttons else\n");
          if(trans->GetPositionY() < groundy) {
            trans->SetYVelocity(5);
          }
          else if(trans->GetPositionY() >= groundy){
            trans->SetJumping(false);
          }
        }
        else {
            trans->SetYVelocity(0);
            trans->SetYPosition(groundy);

        }
        
      }
}

void ControllerComponent::SetTileMaplistOfTiles(int* tilemapListofTiles) {
    tilemapListoftiles = tilemapListofTiles;
}

void ControllerComponent::Update() {
   if(trans->GetPositionY() >= groundy) {
     trans->SetYVelocity(0);
     trans->SetJumping(false);
   }

   if(trans->GetPositionY() <= groundy-200) {
    trans->SetYVelocity(5);
   }

   

    col->SetColliderPos(trans->GetPositionX(), trans->GetPositionY());
   
   
}

void ControllerComponent::Render(SDL_Renderer* renderer) {

}