#include "Component.hpp"

Component::Component(){
}

Component::~Component(){
}
