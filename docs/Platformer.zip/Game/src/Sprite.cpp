#include "Sprite.hpp"

Sprite::Sprite(TransformComponent* trans){
    this->trans = trans;
}

Sprite::~Sprite(){
// TODO: Make sure spritesheet and m_texture are destroyed
// but is this the right place?
    SDL_FreeSurface(m_spriteSheet);
    m_spriteSheet = nullptr;
    SDL_DestroyTexture(m_texture);
}


void Sprite::Update(){
    // The part of the image that we want to render
    m_currentFrame++;
    if(m_currentFrame>m_lastFrame){
        m_currentFrame=0;
    }

    // Here I am selecting which frame I want to draw
    // from our sprite sheet. Think of this as just
    // using a mouse to draw a rectangle around the
    // sprite that we want to draw.
    m_src.x = m_currentFrame*75;
    m_src.y = 0;
    m_src.w = 87;
    m_src.h = 75;

    // Where we want the rectangle to be rendered at.
    // This is an actual 'quad' that will draw our
    // source image on top of.	
    
    m_dest.x = trans->GetPositionX();
    m_dest.y = trans->GetPositionY();
    m_dest.w = 128;
    m_dest.h = 128;



}

void Sprite::Render(SDL_Renderer* ren){
    if(!trans->facingright) {
        SDL_RenderCopyEx(ren, m_texture, &m_src, &m_dest, 0, nullptr, SDL_RendererFlip::SDL_FLIP_HORIZONTAL);
    }
    else{
        SDL_RenderCopy(ren, m_texture, &m_src, &m_dest);
    }
}


void Sprite::LoadImage(std::string filePath, SDL_Renderer* ren){
    m_spriteSheet = SDL_LoadBMP(filePath.c_str());
    if(nullptr == m_spriteSheet){
           SDL_Log("Failed to allocate surface");
    }else{
        SDL_Log("Allocated a bunch of memory to create identical game character");
        // Create a texture from our surface
        // Textures run faster and take advantage 
        // of hardware acceleration
        m_texture = SDL_CreateTextureFromSurface(ren, m_spriteSheet);
    }
}
