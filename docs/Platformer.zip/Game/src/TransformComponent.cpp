#include "TransformComponent.hpp"

TransformComponent::TransformComponent(){
    velocityx = 0;
    velocityy = 0;
    positionx = 0;
    positiony = 0;
    facingright = true;
}

TransformComponent::TransformComponent(int xpws, int ypws){
    positionx = xpws;
    positiony = xpws;
    velocityx = 0;
    velocityy = 0;
    facingright = true;
}

TransformComponent::~TransformComponent(){

}

int TransformComponent::GetPositionX() {
    return positionx;
}

int TransformComponent::GetPositionY() {
    return positiony;
}


int TransformComponent::GetVelocityX(){
    return velocityx;

}
int TransformComponent::GetVelocityY() {
    return velocityy;
}

bool TransformComponent::IsJumping() {
    return jumping;
}

void TransformComponent::SetJumping(bool hump) {
    jumping = hump;
}

void TransformComponent::SetXPosition(int x) {
    positionx = x;
}
void TransformComponent::SetYPosition(int y){
    positiony = y;
}

void TransformComponent::SetPosition(int x, int y){
    SetXPosition(x);
    SetYPosition(y);
}

void TransformComponent::SetXVelocity(int  x) {
    velocityx = x;
}

void TransformComponent::SetYVelocity(int y) {
    velocityy = y;
}

void TransformComponent::SetVelocity(int x, int y) {
    SetXVelocity(x);
    SetYVelocity(y);
}

//start render and update

void TransformComponent::Update() {
    positionx+=velocityx;
    positiony+=velocityy;

    //printf("pos: (%d, %d) Vel: (%d, %d)\n", positionx, positiony, velocityx, velocityy);
}

void TransformComponent::Render(SDL_Renderer* renderer) {
    
}