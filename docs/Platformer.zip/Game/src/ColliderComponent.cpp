#include "ColliderComponent.hpp"

ColliderComponent::ColliderComponent(TransformComponent* parent) {
    colwidth = 0;
    colheight = 0;
    istrigger = false;
    collider = SDL_Rect();
    trans = parent;
    collider.h = colheight;
    collider.w = colwidth;
    collider.x = trans->GetPositionX();
    collider.y = trans->GetPositionY();

}

ColliderComponent::ColliderComponent(TransformComponent* parent, int width, int height) {
    colwidth = width;
    colheight = height;
    istrigger = false;
    collider = SDL_Rect();
    collider.h = colheight;
    collider.w = colwidth;
    trans = parent;
    collider.x = trans->GetPositionX();
    collider.y = trans->GetPositionY();
}

ColliderComponent::~ColliderComponent() {

}

SDL_Rect ColliderComponent::GetCollider() {
    return collider;
}

int ColliderComponent::GetWidth() {
    return colwidth;
}

int ColliderComponent::GetHeight() {
    return colheight;
}

TransformComponent* ColliderComponent::GetTransform() {
    return trans;
}

void ColliderComponent::SetColliderHeight(int height) {
    colheight = height;
}

void ColliderComponent::SetColliderWidth(int width) {
    colwidth = width;
}

void ColliderComponent::SetColliderBounds(int width, int height) {
    SetColliderWidth(width);
    SetColliderHeight(height);
}

void ColliderComponent::SetTrigger(bool newTrigger) {
    istrigger = newTrigger;
}

void ColliderComponent::SetColliderPos(int x, int y) {
    trans->SetPosition(x, y);
    collider.x = trans->GetPositionX();
    collider.y = trans->GetPositionY();
}

bool ColliderComponent::CheckCollisions(ColliderComponent other) {
    SDL_Rect a = collider;
    SDL_Rect b = other.collider;
//The sides of the rectangles
    int leftA, leftB;
    int rightA, rightB;
    int topA, topB;
    int bottomA, bottomB;

    //Calculate the sides of rect A
    leftA = a.x;
    rightA = a.x + a.w;
    topA = a.y;
    bottomA = a.y + a.h;

    //Calculate the sides of rect B
    leftB = b.x;
    rightB = b.x + b.w;
    topB = b.y;
    bottomB = b.y + b.h;

    //printf("boundsA: %d %d %d %d B: %d %d %d %d\n", leftA, rightA, topA, bottomA, leftB, rightB, topB, bottomB);
    
//If any of the sides from A are outside of B
    if( bottomA <= topB )
    {
        //returning 1 when a is on top of b
        return false;
    }

    if( topA >= bottomB )
    {
        //returning 2 when b is on top of a
        return false;
    }

    if( rightA <= leftB )
    {
        //returning 3 when a is to the left of b
        return false;
    }

    if( leftA >= rightB )
    {
        //returning 4 when b is to the left of a
        return false;
    }

    //If none of the sides from A are outside B, return -1
    return true;


}

int ColliderComponent::CheckCollisions(int leftB, int topB, int myHeight, int myWidth) {
    SDL_Rect a = collider;
    //The sides of the rectangles
    int leftA;
    int rightA, rightB;
    int topA;
    int bottomA, bottomB;

    //Calculate the sides of rect A
    leftA = a.x;
    rightA = a.x + a.w;
    topA = a.y;
    bottomA = a.y + a.h;

    //Calculate the sides of rect B
    rightB = leftB + myWidth;
    bottomB = topB + myHeight;

    //If any of the sides from A are outside of B
    if (bottomA <= topB)
    {
        //returning 1 when a is on top of b
        return 1;
    }

    if (topA >= bottomB)
    {
        //returning 2 when b is on top of a
        return 1;
    }

    if (rightA <= leftB)
    {
        //returning 3 when a is to the left of b
        return 2;
    }

    if (leftA >= rightB)
    {
        //returning 4 when b is to the left of a
        return 2;
    }

    //If none of the sides from A are outside B, return -1
    return -1;


}

void ColliderComponent::Update() {

}

void ColliderComponent::Render(SDL_Renderer* renderer) {

}