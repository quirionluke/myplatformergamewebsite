#ifndef SPRITE_H
#define SPRITE_H

#include <string>

#include "GraphicsEngineRenderer.hpp"
#include "Component.hpp"
#include "TransformComponent.hpp"

/**
 * A small class to demonstrate loading sprites.
 * Sprite sheets are often used for loading characters,
 * environments, icons, or other images in a game.
 */
class Sprite : public Component { 
public:

    /**
     * Constructor
     */
    Sprite(TransformComponent* trans);
    /**
     * Constructor
     */

    ~Sprite();
    /**
     * Update the sprites position and frame
     */
    virtual void Update();
    /**
     * Render the sprite 
     */
    virtual void Render(SDL_Renderer* ren);
    /**
     * Load a sprite
     */
    void LoadImage(std::string filePath,SDL_Renderer* ren);

private:
    TransformComponent* trans;

	unsigned int m_firstFrame;
    unsigned int m_lastFrame;
    unsigned int m_currentFrame;
    // An SDL Surface contains pixel data to draw an image
	SDL_Surface* m_spriteSheet;
	SDL_Texture* m_texture;

	SDL_Rect m_src;
	SDL_Rect m_dest;
};

#endif
