#ifndef FINISHLINEBEHAVIOR_HPP
#define FINISHLINEBEHAVIOR_HPP

#include "Component.hpp"
#include "TransformComponent.hpp"
#include "ColliderComponent.hpp"
#include "UI.h"

class FinishLineBehavior : public Component {
    public:
    
        ///The constructor for the finishline takes in the ui component for displaying the score (not implemented)
        FinishLineBehavior(UI* gameendfont);
        ///The destructor for the finishlinebehavior
        ~FinishLineBehavior(); 
        
        ///Returns the position of the finishline
        TransformComponent* GetTransform();
        ///Returns the collider attached to the finishline
        ColliderComponent* GetCollider();

        ///Sets the transform of the finish line
        void SetTransform(TransformComponent* trans);
        ///Sets the collider for the finish line
        void SetCollider(ColliderComponent* col);
        ///Gives the finish line a reference to the player's  collider
        void SetPlayerCollider(ColliderComponent* playercol);

        ///The response to the player hitting the finish line
        void HandleCollision();
        ///Compares if the player has hit the finish line yet
        bool CheckMyCollisions(ColliderComponent other);


        void Update();
        virtual void Render(SDL_Renderer* renderer);


    private:
        TransformComponent* trans;
        ColliderComponent* col;
        ColliderComponent* playercol;

        UI* gameendfont;

        int maxX;
        int minX;



};


#endif