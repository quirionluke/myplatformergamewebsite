#ifndef COLLIDERCOMPONENT_HPP
#define COLLIDERCOMPONENT_HPP

#include "Component.hpp"
#include "TransformComponent.hpp"

///A member of the component family that determines collision between two game objects
class ColliderComponent : public Component{
    public:
        ///The constructor for the collider component, takes in the transform of the parent gameobject
        ColliderComponent(TransformComponent* parent);
        ///The constructor for the collider component, takes in the transform of the parent gameobject, as well as the size of the collider
        ColliderComponent(TransformComponent* parent, int width, int height);
        ///The destructor for the collider component
        ~ColliderComponent();

        ///Returns the rectangle representing the collider
        SDL_Rect GetCollider();
        ///Returns the width of the collider
        int GetWidth();
        ///Returns the height of the collider
        int GetHeight();
        ///Returns whether or not this collider is a trigger
        bool GetTrigger();
        ///Returns the transform of the parent gameobject
        TransformComponent* GetTransform();
        ///Checks if there are any collisions between this gameobject and other
        bool CheckCollisions(ColliderComponent other);
        ///Checks how many sides are colliding with this gameobject
        int CheckCollisions(int leftB, int topB, int myHeight, int myWidth);
        ///Sets the collider's new height
        void SetColliderHeight(int height);
        ///Sets the collider's new width
        void SetColliderWidth(int width);
        ///Sets both the collider height and width
        void SetColliderBounds(int width, int height);
        ///Sets if the collider is a trigger or not
        void SetTrigger(bool newTrigger);
        ///Sets the collider position in world space
        void SetColliderPos(int x, int y);
        ///Updates the collider
        void Update();
        ///Render function for the collider
        void Render(SDL_Renderer* renderer);


    private:
        ///The rectangle that represents the collider
        SDL_Rect collider;
        ///The width of the collider
        int colwidth;
        ///The height of the collider
        int colheight;
        ///The transform of the parent gameobject
        TransformComponent* trans;
        

        bool istrigger;

};

#endif