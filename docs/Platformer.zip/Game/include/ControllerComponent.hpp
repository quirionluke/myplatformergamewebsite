#ifndef CONTROLLERCOMPONENT_HPP 
#define CONTROLLERCOMPONENT_HPP

#include "Component.hpp"
#include "TransformComponent.hpp"
#include "ColliderComponent.hpp"

///This class handles everything the player gameobject should be doing
class ControllerComponent : public Component{
    public:
        ///The constructor takes in the player's transform and their collider
        ControllerComponent(TransformComponent* trans, ColliderComponent* col);
        ~ControllerComponent();

        ///checks if the player can move up
        bool CheckMoveUp();
        ///Check if the player can move down
        bool CheckMoveDown();
        ///Checks if the player can move left
        bool CheckMoveLeft();
        ///Checks if the player can move right
        bool CheckMoveRight();
        ///Checks which directions the player can move (NOT IMPLEMENTED)
        void UpdateCanMove();   
        ///Gives the player a reference to every tile
        void SetTileMaplistOfTiles(int* tilemapListOfTiles);

        virtual void Update();
        ///Handles the player's inputs in how they control their character
        void HandleInputs(SDL_Event e);
        virtual void Render(SDL_Renderer* renderer);

    private:
        TransformComponent* trans;

        ColliderComponent* col;
        int* tilemapListoftiles;

        int groundy;
        bool buttons[3];

        bool canMoveUp;
        bool canMoveDown;
        bool canMoveLeft;
        bool canMoveRight;
};


#endif
