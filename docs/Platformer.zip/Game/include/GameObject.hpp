#ifndef GAMEOBJECT_HPP
#define GAMEOBJECT_HPP

#include <SDL2/SDL.h>
#include <vector>
#include <algorithm>

#include "Component.hpp"
#include "ControllerComponent.hpp"

class GameObject{ 
    public:
        ///The constructor fot the gameobject
        GameObject();
        ///The destructor for the gameobject
        ~GameObject();

        ///Function so that if gameobjects have the required components they can check their collisions
        void CheckCollision(int leftB, int topB, int myWidth, int myHeight);

        void Update();
        void Render(SDL_Renderer* renderer);
        ///A method to handle all of the inputs in the game that relate to this gameobject
        void HandleInputs(SDL_Event e);

        ///Puts a component onto the gameobject
        void AddComponent(Component* comp);
        ///Removes a component from the gameobject
        void RemoveComponent();
    
    private:
        std::vector<Component*> m_components;

};


#endif
