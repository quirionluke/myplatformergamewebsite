#ifndef EMENYBEHAVIOR_HPP
#define ENEMYBEHAVIOR_HPP

#include "Component.hpp"
#include "TransformComponent.hpp"
#include "ColliderComponent.hpp"

class EnemyBehavior : public Component {
    public:
    
        ///The constructor for a new EnemyBehavior
        EnemyBehavior();
        ~EnemyBehavior();
        
        ///Returns the transform of the enemy
        TransformComponent* GetTransform();
        ///Returns the enemy collider
        ColliderComponent* GetCollider();
        ///Sets the transform of the enemy
        void SetTransform(TransformComponent* trans);
        ///Sets the collider of the enemy
        void SetCollider(ColliderComponent* col);
        ///Gives the enemy a reference to the player's collider
        void SetPlayerCollider(ColliderComponent* playercol);
        ///Determines what happens when the player hits an enemy
        void HandleCollision();
    
        /** 
        * Check to see if our enemy has collided with the given ColliderComponent
        */
        bool CheckMyCollisions(ColliderComponent other);
        /**
        * Check to see if our enemy has gone outside of it's bounds
        */
        void MoveEnemy();

        void Update();
        virtual void Render(SDL_Renderer* renderer);


    private:
        TransformComponent* trans;
        ColliderComponent* col;
        ColliderComponent* playercol;

        int maxX;
        int minX;



};


#endif