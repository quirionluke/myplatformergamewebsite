#ifndef TRANSFORMCOMPONENT_HPP
#define TRANSFORMCOMPONENT_HPP

#include "Component.hpp"

class TransformComponent : public Component{
    public:
        ///The default constructor for a transform component
        TransformComponent();
        
        ///The constructor that sets the position used for a 2D position
        TransformComponent(int xpos, int ypos);


        ///The destructor for the transform component
        ~TransformComponent();

        ///The render function for the transform component
        void Render(SDL_Renderer* renderer);
        ///Updates the transform per frame
        void Update();
        
        ///Returns the currennt x position
        int GetPositionX(); 
        ///Returns the current y position
        int GetPositionY();
        ///Returns the current x velocity
        int GetVelocityX();
        ///Returns the current y velocity
        int GetVelocityY();
        ///Returns whether or not the gamobject attached to the transform component is jumping
        bool IsJumping();
        ///Sets the new x position
        void SetXPosition(int x);
        ///Sets the new y position
        void SetYPosition(int y);
        ///Sets the new x and y position
        void SetPosition(int x, int y);
        ///Sets the new x velocity
        void SetXVelocity(int x);
        ///Sets the new y velocity
        void SetYVelocity(int x);
        ///Sets the new X and Y velocity
        void SetVelocity(int x, int y);
        ///Sets whether or not you are jumping
        void SetJumping(bool jump);
        
        ///A variable that states whether or not this transform is facing to the right
        bool facingright;

    private:
        int positionx;
        int positiony;
        int velocityx;
        int velocityy;
        bool jumping;

};


#endif
