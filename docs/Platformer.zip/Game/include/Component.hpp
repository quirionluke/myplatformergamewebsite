#ifndef COMPONENT_HPP 
#define COMPONENT_HPP

#include <SDL2/SDL.h>
#include "vector"

///The component interface to be added to a gameobject
class Component{
    public:
        ///The constructor
        Component();
        virtual ~Component() = 0;
 
        virtual void Render(SDL_Renderer* SDL_Renderer) = 0;
        virtual void Update() = 0;

    private:

};


#endif
